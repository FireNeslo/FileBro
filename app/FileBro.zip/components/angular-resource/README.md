bower-angular-resource
======================

angular-resource bower repo