function CollapseDemoCtrl($scope) {
  $scope.isCollapsed = false;
}
